SALIYA ENTERPRISES - HOST READY

Netlify Drop: upload the entire saliya_host_ready folder (index.html must be at the top level).
This version includes Block Sales (බ්ලොක් ගල් විකුණුම්), received payments, and customer credit.
If updating an existing Netlify site, use Deploys > Deploy manually to upload this folder.
Before updating, download Backup JSON from your current site. Browser storage depends on the website origin; a new site URL may not show old records until restored.
This is a browser-only demo; do not use for sensitive real business data without secure login and database.
